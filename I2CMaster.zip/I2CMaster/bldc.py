import smbus2
import struct
import time

#ポテンショメータのサーボ
class BLDC:
    def __init__(self, slave_addr):
        self.slave_addr = slave_addr
        self.bus = smbus2.SMBus(1) #ラズパイのI2Cバス(通常は1)
        self.data_length = 5
        self.delay_time = 0.0001
        self.accelerationTimeRatio = 0.1
        
    #データをスレーブに送る
    def I2C_send(self, data_addr, data):
        data_bytes = struct.pack('<f', data)
        data_to_send = list(data_bytes)
        self.bus.write_i2c_block_data(self.slave_addr, data_addr, data_to_send)

    #データをスレーブから受け取る
    def I2C_get(self, data_addr):
        received_data = self.bus.read_i2c_block_data(self.slave_addr, data_addr, self.data_length)
        get_bytes = bytes(received_data[1:])
        get_data = struct.unpack('<f', get_bytes)[0]
        return get_data
    
    #現在角度を取得
    def get_Now_Angle(self):
        self.I2C_send(0x11, 0)
        time.sleep(self.delay_time)
        mecAngleNum = self.I2C_get(0x12)
        return mecAngleNum
    
    
    #機械角を0~2πの間で受け取る
    def get_Prev_Angle(self):
        self.I2C_send(0x12, 0)
        time.sleep(self.delay_time)
        mecAngleNum = self.I2C_get(0x12)
        return mecAngleNum
    
    #回転数を受け取る
    def get_Full_Rotations(self):
        self.I2C_send(0x13, 0)
        time.sleep(self.delay_time)
        fullRotations = self.I2C_get(0x13)
        return fullRotations
    
    #電気角度を受け取る
    def get_Angle_el(self):
        self.I2C_send(0x14, 0)
        time.sleep(self.delay_time)
        angle_el = self.I2C_get(0x14)
        return angle_el
    
    #A相のデューティー比を受け取る
    def getDC_A(self):
        self.I2C_send(0x15, 0)
        time.sleep(self.delay_time)
        dc_a = self.I2C_get(0x15)
        return dc_a
    
    #B相のデューティー比を受け取る
    def getDC_B(self):
        self.I2C_send(0x16, 0)
        time.sleep(self.delay_time)
        dc_b = self.I2C_get(0x16)
        return dc_b
    
    #C相のデューティー比を受け取る
    def getDC_C(self):
        self.I2C_send(0x17, 0)
        time.sleep(self.delay_time)
        dc_c = self.I2C_get(0x17)
        return dc_c
    
    #Ualphaを受け取る
    def getU_alpha(self):
        self.I2C_send(0x18, 0)
        time.sleep(self.delay_time)
        Ualpha = self.I2C_get(0x18)
        return Ualpha
    
    #Ubetaを受け取る
    def getU_beta(self):
        self.I2C_send(0x19, 0)
        time.sleep(self.delay_time)
        Ubeta = self.I2C_get(0x19)
        return Ubeta
    
    #Uaを受け取る
    def getU_a(self):
        self.I2C_send(0x1a, 0)
        time.sleep(self.delay_time)
        Ua = self.I2C_get(0x1a)
        return Ua
    
    #Ubを受け取る
    def getU_b(self):
        self.I2C_send(0x1b, 0)
        time.sleep(self.delay_time)
        Ub = self.I2C_get(0x1b)
        return Ub

    #Ucを受け取る
    def getU_c(self):
        self.I2C_send(0x1c, 0)
        time.sleep(self.delay_time)
        Uc = self.I2C_get(0x1c)
        return Uc
    
    #current_aを受け取る
    def getCurrent_a(self):
        self.I2C_send(0x30, 0)
        time.sleep(self.delay_time)
        current_a = self.I2C_get(0x30)
        return current_a
    
    #current_bを受け取る
    def getCurrent_b(self):
        self.I2C_send(0x31, 0)
        time.sleep(self.delay_time)
        currenct_b = self.I2C_get(0x31)
        return currenct_b
    
    #current_cを受け取る
    def getCurrent_c(self):
        self.I2C_send(0x32, 0)
        time.sleep(self.delay_time)
        current_c = self.I2C_get(0x32)
        return current_c
    
    def getCurrent_alpha(self):
        self.I2C_send(0x33, 0)
        time.sleep(self.delay_time)
        current_alpha = self.I2C_get(0x33)
        return current_alpha
    
    def getCurrent_beta(self):
        self.I2C_send(0x34, 0)
        time.sleep(self.delay_time)
        current_beta = self.I2C_get(0x34)
        return current_beta
    
    def getCurrent_d(self):
        self.I2C_send(0x35, 0)
        time.sleep(self.delay_time)
        current_d = self.I2C_get(0x35)
        return current_d
    
    def getCurrent_q(self):
        self.I2C_send(0x36, 0)
        time.sleep(self.delay_time)
        current_q = self.I2C_get(0x36)
        return current_q
    
    def getCurrent_LPF_d(self):
        self.I2C_send(0x37, 0)
        time.sleep(self.delay_time)
        current_q = self.I2C_get(0x37)
        return current_q
    
    def getCurrent_LPF_q(self):
        self.I2C_send(0x38, 0)
        time.sleep(self.delay_time)
        current_q = self.I2C_get(0x38)
        return current_q
    
    def getGoal_current_d(self):
        self.I2C_send(0x40, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x40)
        return num
    
    def getGoal_current_q(self):
        self.I2C_send(0x41, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x41)
        return num
    
    def get_Kp_d(self):
        self.I2C_send(0x42, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x42)
        return num
    
    def get_Kp_q(self):
        self.I2C_send(0x43, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x43)
        return num
    
    def get_Ki_d(self):
        self.I2C_send(0x44, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x44)
        return num
    
    def get_Ki_q(self):
        self.I2C_send(0x45, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x45)
        return num

    def get_offsetA(self):
        self.I2C_send(0x46, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x46)
        return num
    
    def get_offsetB(self):
        self.I2C_send(0x47, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x47)
        return num
    
    def get_offsetC(self):
        self.I2C_send(0x48, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x48)
        return num
    
    def getU_d(self):
        self.I2C_send(0x49, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x49)
        return num
    
    def getU_q(self):
        self.I2C_send(0x50, 0)
        time.sleep(self.delay_time)
        num = self.I2C_get(0x50)
        return num

    


    def setGoal_Current_d(self, goal_current_d):
        self.I2C_send(0x22, goal_current_d)

    def setGoal_Current_q(self, goal_current_q):
        self.I2C_send(0x23, goal_current_q)
    
    def set_Kp_d(self, kp_d):
        self.I2C_send(0x24, kp_d)
    
    def set_Kp_q(self, kp_q):
        self.I2C_send(0x25, kp_q)

    def set_Ki_d(self, ki_d):
        self.I2C_send(0x26, ki_d)
    
    def set_Ki_q(self, ki_q):
        self.I2C_send(0x27, ki_q)

    def set_lowpass_alpha_d(self, data):
        self.I2C_send(0x28, data)

    def set_lowpass_alpha_q(self, data):
        self.I2C_send(0x29, data)
    




    #速度台形則に基づ得くパラメータ設計
    def calc_s_LSPB(self, movement_time):
        time_steps = [i * self.delay_time for i in range(int(movement_time / self.delay_time) + 1)]
        parameter_s_steps = []

        tb = movement_time*self.accelerationTimeRatio
        VM = 1/(movement_time - tb)
        a = VM/tb

        #区間に応じて
        for t in time_steps:

            if 0 <= t < tb:
                s = (a*(t**2))/2
                parameter_s_steps.append(s)

            elif tb <= t < movement_time - tb:
                s = VM*(t - (tb/2))
                parameter_s_steps.append(s)

            elif movement_time - tb <= t <= movement_time:
                s = 1 - (a*((movement_time - t)**2))/2
                parameter_s_steps.append(s)

        return parameter_s_steps
    

    #普通の軌道設計
    def calc_s_normal(self, movement_time):
        time_steps = [i * self.commandCycle for i in range(int(movement_time / self.commandCycle) + 1)]
        parameter_s_steps = []
        for t in time_steps:
            s = t/movement_time
            parameter_s_steps.append(s)

        return parameter_s_steps
    
    #サーボを速度制御用の角度軌道を生成
    def createAngleTrajectory(self, goal_angle_deg, movement_time, LSPB_ON):
        angle_steps = []

        start_angle_deg = self.get_Angle()

        #速度台形則による移動
        if(LSPB_ON == 1):
            parameter_s_steps_theta = self.calc_s_LSPB(movement_time)
            for s in parameter_s_steps_theta:
                angle_deg = start_angle_deg*(1 - s) + goal_angle_deg*s
                angle_steps.append(angle_deg)
        
        #普通の移動
        else:
            parameter_s_steps_theta = self.calc_s_normal(movement_time)
            for s in parameter_s_steps_theta:
                angle_deg = start_angle_deg*(1 - s) + goal_angle_deg*s
                angle_steps.append(angle_deg)
        
        return angle_steps

    #サーボを速度制御
    def move_to_Target_angle(self, goal_angle, movement_time):
        angle_steps = self.createAngleTrajectory(goal_angle, movement_time, 1)
        for angle in angle_steps:
            self.set_GoalAngle(angle)
            time.sleep(self.delay_time)

    def set_AddAngle(self, add):
        self.I2C_send(0x24, add)


    #サーボを終了する
    def close_servo(self):
        self.motor_off()
        self.bus.close()



