#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BLDC current monitor (Graph) ＆ PI‑tuner (Buttons)  ― 2‑window version
---------------------------------------------------------------------
* Window‑1 :「BLDC Graph」 … 実時間 2 秒分の Ia, Ib, Ic ／ Iα, Iβ ／ Id, Iq をライブ表示
              ├ 上段縦軸 : –1.5 ～ 10   [A]   (Ia, Ib, Ic)
              ├ 中段縦軸 : –1.5 ～ 10   [A]   (Iα, Iβ)
              └ 下段縦軸 : –1.5 ～  1.5 [A]   (Id, Iq)
* Window‑2 :「PI Tuner」 … STEP 選択・[+]/[–] ボタンを d 軸 / q 軸で整理
              goal_current, Kp, Ki, そして low‑pass α を即時 I²C 書込み
"""

import sys, threading, queue, time
from collections import deque
import tkinter as tk
from tkinter import ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

import bldc                     # ← あなたの BLDC クラス

# ─────────  定数  ───────── #
I2C_ADDR        = 0x10
WINDOW_SECONDS  = 2.0
SAMPLING_HZ     = 100            # センサ取得 100 Hz

CMD_Q:  queue.Queue[tuple[str, float]] = queue.Queue()
DATA_Q: queue.Queue[
    tuple[float, float, float, float, float, float, float, float, dict]
] = queue.Queue()

# ─────────  I²C ワーカースレッド  ───────── #
def worker() -> None:
    m = bldc.BLDC(I2C_ADDR)

    def safe(getter, default=0.0):
        try:
            return getter()
        except (OSError, AttributeError):
            return default

    params = {                       # 現在パラメータ
        "gd":  safe(m.getGoal_current_d),
        "gq":  safe(m.getGoal_current_q),
        "kpd": safe(m.get_Kp_d),
        "kpq": safe(m.get_Kp_q),
        "kid": safe(m.get_Ki_d),
        "kiq": safe(m.get_Ki_q),
        "ald": 0.0,                  # α は読み出し不可 → 0 初期化
        "alq": 0.0,
    }

    setters = {                      # 書込み関数
        "gd":  m.setGoal_Current_d,
        "gq":  m.setGoal_Current_q,
        "kpd": m.set_Kp_d,
        "kpq": m.set_Kp_q,
        "kid": m.set_Ki_d,
        "kiq": m.set_Ki_q,
        "ald": m.set_lowpass_alpha_d,
        "alq": m.set_lowpass_alpha_q,
    }

    period = 1.0 / SAMPLING_HZ
    t0 = time.time()

    while True:
        tic = time.time()

        # ── コマンド処理 ──
        while not CMD_Q.empty():
            key, delta = CMD_Q.get()
            if key == "__quit__":
                return
            params[key] += delta
            try:
                setters[key](params[key])
            except OSError:
                pass                 # I²C エラー → 無視

        # ── センサ取得 ──
        try:
            Ia     = m.getCurrent_a()
            Ib     = m.getCurrent_b()
            Ic     = m.getCurrent_c()
            Ialpha = m.getCurrent_alpha()
            Ibeta  = m.getCurrent_beta()
            Id     = m.getCurrent_LPF_d()
            Iq     = m.getCurrent_LPF_q()
        except OSError:              # Remote‑I/O error → 0
            Ia = Ib = Ic = Ialpha = Ibeta = Id = Iq = 0.0

        DATA_Q.put((
            time.time() - t0, Ia, Ib, Ic, Ialpha, Ibeta, Id, Iq, params.copy()
        ))

        # ── 周期維持 ──
        dt = time.time() - tic
        if dt < period:
            time.sleep(period - dt)

# ─────────  グラフウィンドウ  ───────── #
class Graph(tk.Toplevel):
    def __init__(self, master=None) -> None:
        super().__init__(master)
        self.title("BLDC Graph")

        # データバッファ
        self.bt = deque()
        self.bIa = deque(); self.bIb = deque(); self.bIc = deque()
        self.bIalpha = deque(); self.bIbeta = deque()
        self.bId = deque(); self.bIq = deque()

        # Figure & Axes  (3 段)
        fig, (self.ax_abc, self.ax_ab, self.ax_dq) = plt.subplots(
            3, 1, sharex=True, figsize=(7, 6)
        )
        # Phase currents
        self.lIa, = self.ax_abc.plot([], [], label="Ia")
        self.lIb, = self.ax_abc.plot([], [], label="Ib")
        self.lIc, = self.ax_abc.plot([], [], label="Ic")
        # α‑β currents
        self.lIalpha, = self.ax_ab.plot([], [], label="Iα")
        self.lIbeta,  = self.ax_ab.plot([], [], label="Iβ")
        # d‑q currents
        self.lId, = self.ax_dq.plot([], [], label="Id (LPF)")
        self.lIq, = self.ax_dq.plot([], [], label="Iq (LPF)")

        for ax in (self.ax_abc, self.ax_ab, self.ax_dq):
            ax.grid(True); ax.legend(loc="upper right")

        self.ax_abc.set_ylabel("Phase [A]")
        self.ax_ab.set_ylabel("α, β [A]")
        self.ax_dq.set_ylabel("d, q [A]")
        self.ax_dq.set_xlabel("Time [s]")

        # 縦軸固定
        self.ax_abc.set_ylim(-6, 6)
        self.ax_ab.set_ylim(-6, 6)
        self.ax_dq.set_ylim(-6, 6)

        self.canvas = FigureCanvasTkAgg(fig, master=self)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    # バッファ追加
    def add_sample(
        self, t, Ia, Ib, Ic, Ialpha, Ibeta, Id, Iq
    ):
        self.bt.append(t)
        self.bIa.append(Ia);     self.bIb.append(Ib);      self.bIc.append(Ic)
        self.bIalpha.append(Ialpha); self.bIbeta.append(Ibeta)
        self.bId.append(Id);     self.bIq.append(Iq)

        while self.bt and t - self.bt[0] > WINDOW_SECONDS:
            self.bt.popleft()
            self.bIa.popleft(); self.bIb.popleft(); self.bIc.popleft()
            self.bIalpha.popleft(); self.bIbeta.popleft()
            self.bId.popleft(); self.bIq.popleft()

    # 再描画
    def redraw(self):
        if not self.bt:
            return

        # データ設定
        self.lIa.set_data(self.bt, self.bIa)
        self.lIb.set_data(self.bt, self.bIb)
        self.lIc.set_data(self.bt, self.bIc)
        self.lIalpha.set_data(self.bt, self.bIalpha)
        self.lIbeta.set_data(self.bt, self.bIbeta)
        self.lId.set_data(self.bt, self.bId)
        self.lIq.set_data(self.bt, self.bIq)

        # 表示範囲更新
        xmin = self.bt[-1] - WINDOW_SECONDS
        xmax = self.bt[-1] if self.bt[-1] > WINDOW_SECONDS else WINDOW_SECONDS
        for ax in (self.ax_abc, self.ax_ab, self.ax_dq):
            ax.set_xlim(xmin, xmax)

        self.canvas.draw_idle()

# ─────────  PI‑Tuner ウィンドウ  ───────── #
class Tuner(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("PI Tuner")
        self.step = tk.DoubleVar(value=0.1)

        # STEP 選択
        tk.Label(self, text="STEP").grid(row=0, column=0, sticky="w", padx=2, pady=2)
        for i, s in enumerate([1, 0.1, 0.01, 0.001, 0.0001]):
            ttk.Radiobutton(
                self, text=str(s), value=s, variable=self.step
            ).grid(row=0, column=i + 1, sticky="w")

        # d / q フレーム
        frm_d = ttk.LabelFrame(self, text="d‑axis", padding=(4, 2))
        frm_q = ttk.LabelFrame(self, text="q‑axis", padding=(4, 2))
        frm_d.grid(row=1, column=0, columnspan=5, sticky="nsew", padx=2, pady=2)
        frm_q.grid(row=2, column=0, columnspan=5, sticky="nsew", padx=2, pady=2)

        # ラベル用 StringVar
        self.pvar: dict[str, tk.StringVar] = {}

        layout = [
            ("gd",  "goal_d", frm_d), ("gq",  "goal_q", frm_q),
            ("kpd", "Kp_d",   frm_d), ("kpq", "Kp_q",   frm_q),
            ("kid", "Ki_d",   frm_d), ("kiq", "Ki_q",   frm_q),
            ("ald", "α_d",    frm_d), ("alq", "α_q",    frm_q),
        ]

        for row, (key, label, parent) in enumerate(layout):
            ttk.Label(parent, text=label, width=6
                      ).grid(row=row, column=0, sticky="e", padx=(0, 2))
            ttk.Button(parent, text=" + ", width=3,
                       command=lambda k=key: self.delta(k, +1)
                       ).grid(row=row, column=1)
            ttk.Button(parent, text=" − ", width=3,
                       command=lambda k=key: self.delta(k, -1)
                       ).grid(row=row, column=2)
            self.pvar[key] = tk.StringVar(value="0.000")
            ttk.Label(parent, textvariable=self.pvar[key],
                      width=8, anchor="e"
                      ).grid(row=row, column=3, padx=(2, 0))

        self.after(30, self.update_ui)

    def delta(self, key: str, sign: int):
        CMD_Q.put((key, self.step.get() * sign))

    def update_ui(self):
        changed = False
        while not DATA_Q.empty():
            t, Ia, Ib, Ic, Ialpha, Ibeta, Id, Iq, prm = DATA_Q.get()
            GRAPH.add_sample(t, Ia, Ib, Ic, Ialpha, Ibeta, Id, Iq)
            changed = True
            for k, var in self.pvar.items():
                var.set(f"{prm[k]:.3f}")
        if changed:
            GRAPH.redraw()
        self.after(30, self.update_ui)

    def on_close(self):
        CMD_Q.put(("__quit__", 0.0))
        self.destroy()
        GRAPH.destroy()

# ─────────  Main  ───────── #
def main():
    threading.Thread(target=worker, daemon=True).start()

    global GRAPH
    tuner = Tuner()
    GRAPH = Graph(tuner)          # グラフは Tuner の子ウィンドウ
    tuner.protocol("WM_DELETE_WINDOW", tuner.on_close)
    tuner.mainloop()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        CMD_Q.put(("__quit__", 0.0))
        sys.exit(0)
