#!/usr/bin/env python3
# monitor_bldc_rt_Iabc.py
import sys, threading, queue, time
from collections import deque
import tkinter as tk
from tkinter import ttk

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

from bldc import BLDC

I2C_ADDR       = 0x10
SAMPLING_HZ    = 200
WINDOW_SECONDS = 2.0

CMD_Q:  queue.Queue[tuple[str, float]] = queue.Queue()
DATA_Q: queue.Queue[tuple[float, float, float, float, float, float, float, dict]] = queue.Queue()

# ---------------- Worker ----------------
def worker():
    bldc = BLDC(I2C_ADDR)

    def safe(getter, default=0.0):
        try:
            return getter()
        except OSError:
            return default

    params = {
        "gd": safe(bldc.getGoal_current_d),
        "gq": safe(bldc.getGoal_current_q),
        "kpd": safe(bldc.get_Kp_d),   "kpq": safe(bldc.get_Kp_q),
        "kid": safe(bldc.get_Ki_d),   "kiq": safe(bldc.get_Ki_q),
        "ald": 0.0,                   "alq": 0.0,
    }
    setters = {
        "gd": bldc.setGoal_Current_d, "gq": bldc.setGoal_Current_q,
        "kpd": bldc.set_Kp_d,         "kpq": bldc.set_Kp_q,
        "kid": bldc.set_Ki_d,         "kiq": bldc.set_Ki_q,
        "ald": bldc.set_lowpass_alpha_d,
        "alq": bldc.set_lowpass_alpha_q,
    }

    period = 1.0 / SAMPLING_HZ
    t0 = time.perf_counter()

    while True:
        tic = time.perf_counter()

        # キューにたまったコマンドを処理
        while not CMD_Q.empty():
            key, delta = CMD_Q.get()
            if key == "__quit__":
                return
            params[key] += delta
            try:
                setters[key](params[key])
            except OSError:
                pass

        # データ取得
        try:
            ang_el = bldc.get_Angle_el()
            ia, ib, ic = bldc.getCurrent_a(), bldc.getCurrent_b(), bldc.getCurrent_c()
            id_lpf = bldc.getCurrent_LPF_d()
            iq_lpf = bldc.getCurrent_LPF_q()
        except OSError:
            ang_el = ia = ib = ic = id_lpf = iq_lpf = 0.0

        DATA_Q.put((time.perf_counter()-t0, ang_el, ia, ib, ic, id_lpf, iq_lpf, params.copy()))

        # サンプリング周期を維持
        dt = time.perf_counter() - tic
        if dt < period:
            time.sleep(period - dt)

# ---------------- Graph ----------------
class Graph(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("BLDC – currents & angle")

        self.t = deque()
        self.el = deque()
        self.iA, self.iB, self.iC = deque(), deque(), deque()
        self.idLPF, self.iqLPF = deque(), deque()

        fig, (ax_el, ax_iabc, ax_idq) = plt.subplots(3, 1, sharex=True, figsize=(7, 6))
        self.lEl,    = ax_el.plot([], [],      label="angle_el")
        self.lA,     = ax_iabc.plot([], [],     label="I_a")
        self.lB,     = ax_iabc.plot([], [],     label="I_b")
        self.lC,     = ax_iabc.plot([], [],     label="I_c")
        self.lIdLPF, = ax_idq.plot([], [],      label="I_d_LPF")
        self.lIqLPF, = ax_idq.plot([], [],      label="I_q_LPF")

        ax_el.set_ylabel("rad");           ax_el.set_ylim(0, 6.3);      ax_el.grid(); ax_el.legend()
        ax_iabc.set_ylabel("Phase I [A]"); ax_iabc.set_ylim(-2.5, 2.5);     ax_iabc.grid(); ax_iabc.legend()
        ax_idq.set_ylabel("I_dq_LPF [A]"); ax_idq.set_ylim(-5, 5);     ax_idq.set_xlabel("time [s]"); ax_idq.grid(); ax_idq.legend()

        self.ax_el, self.canvas = ax_el, FigureCanvasTkAgg(fig, master=self)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

    def add(self, t, el, ia, ib, ic, id_lpf, iq_lpf):
        self.t.append(t);   self.el.append(el)
        self.iA.append(ia); self.iB.append(ib); self.iC.append(ic)
        self.idLPF.append(id_lpf); self.iqLPF.append(iq_lpf)
        while self.t and t - self.t[0] > WINDOW_SECONDS:
            self.t.popleft(); self.el.popleft()
            self.iA.popleft(); self.iB.popleft(); self.iC.popleft()
            self.idLPF.popleft(); self.iqLPF.popleft()

    def redraw(self):
        if not self.t:
            return
        xmin = self.t[-1] - WINDOW_SECONDS
        self.ax_el.set_xlim(xmin, self.t[-1])
        for line, data in zip(
            [self.lEl, self.lA, self.lB, self.lC, self.lIdLPF, self.lIqLPF],
            [self.el,  self.iA, self.iB, self.iC, self.idLPF,      self.iqLPF]):
            line.set_data(self.t, data)
        self.canvas.draw_idle()

# ---------------- Tuner ----------------
class Tuner(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("PI Tuner")

        # BLDC インスタンス（初期値読み込み用）
        self.bldc = BLDC(I2C_ADDR)
        def safe(getter, default=0.0):
            try:
                return getter()
            except:
                return default

        # パラメータ初期値
        self.params = {
            "gd":  safe(self.bldc.getGoal_current_d),
            "gq":  safe(self.bldc.getGoal_current_q),
            "kpd": safe(self.bldc.get_Kp_d),
            "kpq": safe(self.bldc.get_Kp_q),
            "kid": safe(self.bldc.get_Ki_d),
            "kiq": safe(self.bldc.get_Ki_q),
            "ald": 0.0,
            "alq": 0.0,
        }

        self.step = tk.DoubleVar(value=0.1)

        # ステップ選択ボタン（4つ）
        ttk.Label(self, text="STEP").grid(row=0, column=0, padx=5, pady=5)
        for col, val in enumerate([1.0, 0.1, 0.01, 0.001], start=1):
            ttk.Radiobutton(
                self,
                text=str(val),
                value=val,
                variable=self.step
            ).grid(row=0, column=col)

        # パラメータ一覧と操作ボタン
        params = [
            ("gd",  "Goal_d"),
            ("gq",  "Goal_q"),
            ("kpd", "Kp_d"),
            ("kpq", "Kp_q"),
            ("kid", "Ki_d"),
            ("kiq", "Ki_q"),
            ("ald", "alpha_d"),
            ("alq", "alpha_q"),
        ]
        self.value_labels: dict[str, ttk.Label] = {}

        for idx, (key, label) in enumerate(params, start=1):
            ttk.Label(self, text=label).grid(row=idx, column=0, padx=5, pady=2)
            ttk.Button(
                self, text="+", width=3,
                command=lambda k=key: self.change_param(k,  self.step.get())
            ).grid(row=idx, column=1)
            ttk.Button(
                self, text="-", width=3,
                command=lambda k=key: self.change_param(k, -self.step.get())
            ).grid(row=idx, column=2)
            lbl = ttk.Label(self, text=f"{self.params[key]:.3f}")
            lbl.grid(row=idx, column=3, padx=5)
            self.value_labels[key] = lbl

        # 定期更新開始
        self.after(30, self.refresh)

    def change_param(self, key: str, delta: float):
        self.params[key] += delta
        self.value_labels[key].configure(text=f"{self.params[key]:.3f}")
        CMD_Q.put((key, delta))

    def refresh(self):
        while not DATA_Q.empty():
            t, el, ia, ib, ic, id_lpf, iq_lpf, _ = DATA_Q.get()
            GRAPH.add(t, el, ia, ib, ic, id_lpf, iq_lpf)
        GRAPH.redraw()
        self.after(30, self.refresh)

    def on_close(self):
        CMD_Q.put(("__quit__", 0.0))
        self.destroy()
        GRAPH.destroy()

# ---------------- MAIN ----------------
def main():
    threading.Thread(target=worker, daemon=True).start()
    global GRAPH
    tuner = Tuner()
    GRAPH = Graph(tuner)
    tuner.protocol("WM_DELETE_WINDOW", tuner.on_close)
    tuner.mainloop()

if __name__ == "__main__":
    main()
