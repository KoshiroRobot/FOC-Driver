/*
 * angle_sensor.h
 *
 *  Created on: Feb 19, 2025
 *      Author: taise
 */

#ifndef ANGLE_SENSOR_H
#define ANGLE_SENSOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "foc.h"

#define _3PI_2 (3.0 * M_PI / 2.0)

/* 構造体: 磁気センサの状態 */
typedef struct {
    float prev_angle_rad;        // 前回の角度（ラジアン）
    float full_rotations;        // 回転数カウンタ
    float now_angle;             // 現在の多回転角度（ラジアン）
    float angle_el;              // 電気角
    float zero_electric_angle;   // 電気角オフセット
    int magnet_ok;               // 磁石の状態（1 = OK, 0 = NG）
    float initial_angle_rad;     // 初期角度（ラジアン）
} MagnetSensorState;

extern volatile MagnetSensorState angle_sensor_state;

/* 初期化：初期角度を取得して状態構造体を初期化 */
void InitMagnetSensorState(volatile MagnetSensorState* state);

/* 磁石強度をチェックして状態を更新 */
void UpdateMagnetStrengthStatus(volatile MagnetSensorState* state);

/* 角度と回転数，電気角を更新 */
void Update_Magnet_Angle(volatile MagnetSensorState* state);

/* ゼロ電気角をキャリブレーション（整列） */
void CalibrateZeroElectricAngle(volatile MagnetSensorState* state, volatile FOCState_s* foc_state);

#ifdef __cplusplus
}
#endif

#endif /* ANGLE_SENSOR_H */
