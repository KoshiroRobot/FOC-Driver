/*
 * foc.h
 *
 *  Created on: Feb 19, 2025
 *      Author: taise
 */



#ifndef INC_FOC_H_
#define INC_FOC_H_

#include "main.h"

struct CurrentSensorState;

typedef enum {
    CTRL_CLOSED_FOC,       // 普段の FOC
    CTRL_OPEN_SENSORTEST   // オープンループ（センサ確認）
} ControlMode_e;

extern volatile ControlMode_e g_control_mode;

typedef enum {
    FOC_ALIGN,          // 整列（固定電圧）
    FOC_RAMP,           // オープンループ加速
    FOC_CLOSED          // 通常 FOC
} FOC_Stage_e;

typedef struct FOCState_s{
    float Ua;
    float Ub;
    float Uc;
    float Ualpha;
    float Ubeta;
    float Ud;
    float Uq;
    float dc_a;
    float dc_b;
    float dc_c;
    float goal_current_d;
    float goal_current_q;
    float kp_d;
    float kp_q;
    float ki_d;
    float ki_q;
    float lowpass_alpha_d;
    float lowpass_alpha_q;
    float integral_d;
    float integral_q;

	float       theta_ol;   // ramp 用の自前角度 [rad]
	uint32_t    tick;
} FOCState_s;

extern volatile FOCState_s foc_state;


#ifndef _PI
#define _PI       3.14159265358979323846f
#endif

#ifndef _TWO_PI
#define _TWO_PI   (2.0f * _PI)
#endif

#ifndef _3PI_2
#define _3PI_2    (1.5f * _PI)
#endif

/* 整列に使う q 軸電圧 [V]  */
#ifndef VOLTAGE_ALIGN
#define VOLTAGE_ALIGN  1.0f
#endif

void PI_current_dq(volatile FOCState_s *foc_state, volatile struct CurrentSensorState *current_state);

void setPhaseVoltage(volatile FOCState_s* foc_state, float angle_el, TIM_HandleTypeDef *htim);

void FOC_FastLoop(void);

void FOC_OpenLoopSensorTest(void);

#endif /* INC_FOC_H_ */
