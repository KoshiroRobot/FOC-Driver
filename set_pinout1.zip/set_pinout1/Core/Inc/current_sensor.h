/*
 * current_sensor.h
 *
 *  Created on: Feb 23, 2025
 *      Author: taise
 */

#ifndef CURRENT_SENSOR_H
#define CURRENT_SENSOR_H


#include "main.h"
#include "foc.h"

#define SVPWM_FREQUENCY_HZ 5000.0f
#define DT (1.0f / SVPWM_FREQUENCY_HZ)


typedef struct CurrentSensorState {
    float a;
    float b;
    float c;
    float alpha;
    float beta;
    float d;
    float q;
    float prev_d;
    float prev_q;
    float lowpass_d;
    float lowpass_q;
    float offsetA;
    float offsetB;
    float offsetC;
    float gainA,  gainB,  gainC;
    uint8_t initialized;
    uint8_t offset_ready;
} CurrentSensorState;

extern volatile CurrentSensorState current_sensor_state;

float Convert_ADC_to_Current(uint32_t adc_value);

void getDQCurrents(volatile CurrentSensorState *state, float angle_el);

void LPF_current_dq(volatile CurrentSensorState *state, volatile FOCState_s* foc_state);

#endif

