/*
 * current_sensor.c
 *
 *  Created on: Feb 23, 2025
 *      Author: taise
 */


#include "foc.h"
#include "current_sensor.h"
volatile CurrentSensorState current_sensor_state = {
    .gainA = 0.900f, .gainB = 0.950f, .gainC = 1.000f
};

#include <math.h>

#define ADC_REF_VOLTAGE 3.239
#define ADC_RESOLUTION 4095
#define SHUNT_RESISTANCE 0.002
#define CURRENT_AMP_GAIN 50


#define _1_SQRT3  (0.57735026919f)
#define _2_SQRT3  (1.15470053838f)

float Convert_ADC_to_Current(uint32_t adc_value)
{
    float voltage = (((float)adc_value / ADC_RESOLUTION) * ADC_REF_VOLTAGE) - (ADC_REF_VOLTAGE / 2);
    float current = voltage / (SHUNT_RESISTANCE * CURRENT_AMP_GAIN);
    return current;
}


/* A/D → 電流 (float 版) */
static inline float ADC_to_I(int32_t adc_diff)
{
    /* ADC 差分を物理電流[A] に変換 */
    float voltage = (((float)adc_diff / ADC_RESOLUTION) * ADC_REF_VOLTAGE);
    return voltage / (SHUNT_RESISTANCE * CURRENT_AMP_GAIN);
}

/* ------------ コールバック ------------ */
/* ------------ コールバック ------------ */
void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc->Instance != ADC1) return;

    int32_t rawC = (int32_t)HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_1);
    int32_t rawA = (int32_t)HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_2);
    int32_t rawB = (int32_t)HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_3);

    //int32_t rawA = (int32_t)HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_1);
	//int32_t rawC = (int32_t)HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_2);
	//int32_t rawB = (int32_t)HAL_ADCEx_InjectedGetValue(hadc, ADC_INJECTED_RANK_3);

    /* ---- オフセット学習 ---- */
    static uint32_t cnt = 0;
    static float sumA = 0, sumB = 0, sumC = 0;
    const uint32_t CAL_SAMPLES = 2000;

    if (!current_sensor_state.offset_ready) {
        sumA += rawA;  sumB += rawB;  sumC += rawC;
        if (++cnt == CAL_SAMPLES) {
            current_sensor_state.offsetA = sumA / CAL_SAMPLES;
            current_sensor_state.offsetB = sumB / CAL_SAMPLES;
            current_sensor_state.offsetC = sumC / CAL_SAMPLES;
            current_sensor_state.offset_ready = 1;
        }
        return;                     // 学習中は制御しない
    }

    /* ---- オフセット補正 → 電流[A] へ ---- */
    float ia = ADC_to_I(rawA - current_sensor_state.offsetA);
    float ib = ADC_to_I(rawB - current_sensor_state.offsetB);
    float ic = ADC_to_I(rawC - current_sensor_state.offsetC);

    /* ---- ゲイン補正 ---- */
    ia *= current_sensor_state.gainA;
    ib *= current_sensor_state.gainB;
    ic *= current_sensor_state.gainC;

    /* ---- 平均値を引いて「0 中心」へ ---- */
    float mid = (ia + ib + ic) * (1.0f / 3.0f);
    current_sensor_state.a = ia - mid;
    current_sensor_state.b = ib - mid;
    current_sensor_state.c = ic - mid;

    /* ---- 後続制御 ---- */
    if (g_control_mode == CTRL_CLOSED_FOC) {
        FOC_FastLoop();
    } else {                        // CTRL_OPEN_SENSORTEST
        FOC_OpenLoopSensorTest();
    }
}





void getDQCurrents(volatile CurrentSensorState *state, float angle_el)
{
  //Clarke変換
  float mid = (1.f/3)*(state->a + state->b + state->c);
  float a = state->a - mid;
  float b = state->b - mid;
  state->alpha = a;
  state->beta  = _1_SQRT3 * a + _2_SQRT3 * b;
  //Park変換
  float st = sinf(angle_el);
  float ct = cosf(angle_el);
  state->d = state->alpha * ct + state->beta * st;
  state->q = state->beta  * ct - state->alpha * st;
}


void LPF_current_dq(volatile CurrentSensorState *state, volatile FOCState_s* foc_state)
{
	if(!state->initialized){          // 初回だけゼロ初期化
	    state->prev_d = state->d;
	    state->prev_q = state->q;
	    state->initialized = 1;
	}
    state->lowpass_d = state->prev_d + foc_state->lowpass_alpha_d * (state->d  - state->prev_d);
    state->lowpass_q = state->prev_q + foc_state->lowpass_alpha_q * (state->q  - state->prev_q);
    state->prev_d = state->lowpass_d;
    state->prev_q = state->lowpass_q;
}






