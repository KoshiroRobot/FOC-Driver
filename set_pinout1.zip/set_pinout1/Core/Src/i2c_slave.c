/*
 * i2c_slave.c
 *
 *  Created on: Feb 18, 2025
 *      Author: taise
 */


#include "angle_sensor.h"
#include "main.h"
#include "i2c_slave.h"
#include "foc.h"
#include "current_sensor.h"
#include <string.h>


//test
extern float angle_el;
extern float dc_a;
extern float dc_b;
extern float dc_c;
extern float Ualpha;
extern float Ubeta;
extern float Ua;
extern float Ub;
extern float Uc;

extern  float current_a;
extern  float current_b;
extern  float current_c;



extern float vq;
extern float vd;
extern float iq;
extern float id;

extern float goal_angle;
extern float add;


//I2Cで必要な最小限コード-------------------------------------------------


float selectData = 0;
float getData = 0;
float sendData = 0;


//i2cでやり取りするメモリサイズを決定(RX受信，TX送信）
#define RxSize 5
#define TxSize 5
static uint8_t RxData[RxSize] = {0};
static uint8_t TxData[TxSize] = {0};

void HAL_I2C_ListenCpltCallback(I2C_HandleTypeDef *hi2c)
{
	HAL_I2C_EnableListen_IT(hi2c);
}


void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hi2c, uint8_t TransferDirection, uint16_t AddrMatchCode)
{
	if(TransferDirection == I2C_DIRECTION_TRANSMIT)
	{
		HAL_I2C_Slave_Sequential_Receive_IT(hi2c, RxData, RxSize, I2C_FIRST_AND_LAST_FRAME);
	}
	else
	{
		HAL_I2C_Slave_Sequential_Transmit_IT(hi2c, TxData, TxSize, I2C_FIRST_AND_LAST_FRAME);
	}
}


void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef* hi2c)
{
	memset(TxData, 0, TxSize);
    float Data = *((float*) (RxData + 1));

    switch (RxData[0])//データに応じて値を決定
    {
    case 0x01: // モータON
    {
    	selectData = 1;
    	break;
    }
    // 0x1- : マスターへの情報準備
    case 0x11:
	{
		float val = angle_sensor_state.now_angle;
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &val;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x12:
	{
		float val = angle_sensor_state.prev_angle_rad;
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &val;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x13:
	{
		float val = angle_sensor_state.full_rotations;
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &val;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x14:
	{
		float val = angle_sensor_state.angle_el;
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &val;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x15:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.dc_a;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x16:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.dc_b;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x17:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.dc_c;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x18:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.Ualpha;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x19:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.Ubeta;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x1a:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.Ua;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x1b:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.Ub;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x1c:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.Uc;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x30:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.a;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x31:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.b;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x32:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.c;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x33:
    {
    	TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.alpha;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
    }
    case 0x34:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.beta;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x35:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.d;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x36:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.q;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x37:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.lowpass_d;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x38:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.lowpass_q;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x40:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.goal_current_d;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x41:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.goal_current_q;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x42:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.kp_d;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x43:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.kp_q;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x44:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.ki_d;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
	case 0x45:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.ki_q;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
	case 0x46:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.offsetA;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
	case 0x47:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.offsetB;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
	case 0x48:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_sensor_state.offsetC;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
	case 0x49:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.Ud;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
	case 0x50:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &foc_state.Uq;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}






    // 0x2- : マスターから情報を受け取る
	case 0x21:
	{
		getData = Data;
		break;
	}
	case 0x22:
	{
		foc_state.goal_current_d = Data;
		break;
	}
	case 0x23:
	{
		foc_state.goal_current_q = Data;
		break;
	}
	case 0x24:
	{
		foc_state.kp_d = Data;
		break;
	}
	case 0x25:
	{
		foc_state.kp_q = Data;
		break;
	}
	case 0x26:
	{
		foc_state.ki_d = Data;
		break;
	}
	case 0x27:
	{
		foc_state.ki_q = Data;
		break;
	}
	case 0x28:
	{
		foc_state.lowpass_alpha_d = Data;
		break;
	}
	case 0x29:
	{
		foc_state.lowpass_alpha_q = Data;
		break;
	}

	default:
		break;
    }
}




