/*
 * sensor.c
 *
 *  Created on: Feb 19, 2025
 *      Author: taise
 */


#include "angle_sensor.h"
volatile MagnetSensorState angle_sensor_state;
#include "main.h"
#include "i2c_slave.h"
#include "foc.h"

#include <math.h>


//マクロ変数を定義
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif


#define MAGHIGH GPIO_PIN_0
#define MAGHIGH_PORT GPIOB
#define MAGLOW GPIO_PIN_1
#define MAGLOW_PORT GPIOB

#define POLE_PAIRS 21
#define SENSOR_DIRECTION 1 //(1 or -1)


/* extern で宣言すると main.c 側の hspi1 を使える */
extern SPI_HandleTypeDef hspi1;
extern TIM_HandleTypeDef htim1;



//磁気センサの状態をチェック
void UpdateMagnetStrengthStatus(volatile MagnetSensorState* state)
{
    GPIO_PinState mag_high = HAL_GPIO_ReadPin(MAGHIGH_PORT, MAGHIGH);
    GPIO_PinState mag_low  = HAL_GPIO_ReadPin(MAGLOW_PORT, MAGLOW);
    state->magnet_ok = (mag_high == GPIO_PIN_RESET && mag_low == GPIO_PIN_RESET) ? 1 : 0;
}

//角度を16ビットで読み取る関数 (元の static 関数)
static uint16_t ReadMagAlphaAngle(void)
{
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET); // CS=Low

    uint16_t txData = 0x0000;
    uint16_t rxData = 0x0000;

    /* 16ビット送受信 */
    HAL_StatusTypeDef ret = HAL_SPI_TransmitReceive(&hspi1,
        (uint8_t*)&txData, (uint8_t*)&rxData, 1, 100U);

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);   // CS=High

    if (ret != HAL_OK){
        // 必要ならエラー処理
    }
    return rxData;
}

float _normalizeAngle(float angle) {
    while (angle > 2.0f * (float)M_PI) {
        angle -= 2.0f * (float)M_PI;
    }
    while (angle < 0) {
        angle += 2.0f * (float)M_PI;
    }
    return angle;
}

//初期化関数：最初に呼び出して初期の角度を保持する
void InitMagnetSensorState(volatile MagnetSensorState* state)
{
    uint16_t angle16 = ReadMagAlphaAngle();
    float mecAngleNum = (float)(angle16 >> 4);
    float initial_angle = mecAngleNum * (2.0f * (float)M_PI) / 4095.0f;

    state->initial_angle_rad = initial_angle;
    state->prev_angle_rad = initial_angle;   // 初回更新時の基準となる
    state->full_rotations = 0.0f;
    state->now_angle = initial_angle;        // 初期時点では角度 = now_angle
    state->angle_el = 0.0f;                  // 初期時点では0にしておく
    state->zero_electric_angle = 0.0f;       // キャリブレーション前の仮値
}

//角度更新：再度読み取って角度を計算し，回転数などを更新する
void Update_Magnet_Angle(volatile MagnetSensorState* state)
{
    uint16_t angle16 = ReadMagAlphaAngle();
    float mecAngleNum = (float)(angle16 >> 4);
    float angle_rad = mecAngleNum * (2.0f * (float)M_PI) / 4096.0f;
    float delta_angle = angle_rad - state->prev_angle_rad;

    if (fabsf(delta_angle) > 0.8f * 2.0f * (float)M_PI) {
        state->full_rotations += (delta_angle > 0.0f) ? -1 : 1;
    }

    state->prev_angle_rad = angle_rad;

    state->angle_el = _normalizeAngle((float)(SENSOR_DIRECTION * POLE_PAIRS) * angle_rad - state->zero_electric_angle);
    state->now_angle = (2.0f * (float)M_PI * state->full_rotations) + angle_rad;
}

//ゼロ電気角を設定する
void CalibrateZeroElectricAngle(volatile MagnetSensorState* state, volatile FOCState_s* foc_state)
{
    // 1. モータに一定の電流を流してロータを固定（整列）
	foc_state->Uq = VOLTAGE_ALIGN;
	foc_state->Ud = 0;
    setPhaseVoltage(foc_state, _3PI_2, &htim1);
    HAL_Delay(700);  // 安定化待ち
    // 2. 現在の角度情報を更新
    state->zero_electric_angle = 0.0f;
    Update_Magnet_Angle(state);
    // 3. このときの電気角をゼロとみなす
    state->zero_electric_angle = state->angle_el;
    HAL_Delay(20);  // 少し待機
    // 4. 電流を止めてロータをフリーに戻す
    foc_state->Uq = 0;
    foc_state->Ud = 0;
    setPhaseVoltage(foc_state, _3PI_2, &htim1);
    HAL_Delay(200);
}











