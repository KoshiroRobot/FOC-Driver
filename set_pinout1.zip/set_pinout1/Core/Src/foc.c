/*
 * foc.c
 *
 *  Created on: Feb 19, 2025
 *      Author: taise
 */

#include "foc.h"
volatile FOCState_s foc_state;

#include "main.h"
extern TIM_HandleTypeDef htim1;

#include "current_sensor.h"

#include "angle_sensor.h"
#include "main.h"
#include "i2c_slave.h"
#include <math.h>

#define ALIGN_TIME_MS     1000      // 整列時間




#ifndef min
  #define min(a,b)  (( (a) < (b) ) ? (a) : (b))
#endif

#ifndef max
  #define max(a,b)  (( (a) > (b) ) ? (a) : (b))
#endif

#ifndef _constrain
  #define _constrain(x, min_val, max_val)  ( ((x)<(min_val)) ? (min_val) : (((x)>(max_val)) ? (max_val) : (x)) )
#endif


#define _SQRT3_2  0.86602540378f
#define VOLTAGE_POWER_SUPPLY 16.8f
#define VOLTAGE_LIMIT  (VOLTAGE_POWER_SUPPLY * 0.866f)

#define INTEGRAL_D_MAX 1
#define INTEGRAL_Q_MAX 1


void PI_current_dq(volatile FOCState_s *foc_state, volatile struct CurrentSensorState *current_state)
{
	float error_d = foc_state->goal_current_d - current_state->lowpass_d;
	float error_q = foc_state->goal_current_q - current_state->lowpass_q;

	float pTerm_d = foc_state->kp_d * error_d;
	float pTerm_q = foc_state->kp_q * error_q;

	foc_state->integral_d += error_d * DT;
	foc_state->integral_q += error_q * DT;

	foc_state->integral_d = _constrain(foc_state->integral_d,
									   -INTEGRAL_D_MAX, INTEGRAL_D_MAX);
	foc_state->integral_q = _constrain(foc_state->integral_q,
									   -INTEGRAL_Q_MAX, INTEGRAL_Q_MAX);

	float iTerm_d = foc_state->ki_d * foc_state->integral_d;
	float iTerm_q = foc_state->ki_q * foc_state->integral_q;

	foc_state->Ud = pTerm_d + iTerm_d;
	foc_state->Uq = pTerm_q + iTerm_q;

	const float U_MAX2 = VOLTAGE_LIMIT * VOLTAGE_LIMIT;
	float mag2 = foc_state->Ud * foc_state->Ud + foc_state->Uq * foc_state->Uq;

	if (mag2 > U_MAX2) {
	    float k = VOLTAGE_LIMIT / sqrtf(mag2);
	    foc_state->Ud *= k;
	    foc_state->Uq *= k;

	    /* 積分項を少し戻す (0.5 は経験的なゲイン) */
	    foc_state->integral_d -= error_d * DT * 0.5f;
	    foc_state->integral_q -= error_q * DT * 0.5f;

	    /* もう一度クランプ */
	    foc_state->integral_d = _constrain(foc_state->integral_d,
	                                       -INTEGRAL_D_MAX, INTEGRAL_D_MAX);
	    foc_state->integral_q = _constrain(foc_state->integral_q,
	                                       -INTEGRAL_Q_MAX, INTEGRAL_Q_MAX);
	}
}


static inline void FOC_StartupStep(void)
{
	Update_Magnet_Angle(&angle_sensor_state);
    getDQCurrents(&current_sensor_state, angle_sensor_state.angle_el);
    LPF_current_dq(&current_sensor_state, &foc_state);
    PI_current_dq(&foc_state, &current_sensor_state);
    setPhaseVoltage(&foc_state, angle_sensor_state.angle_el, &htim1);
}








//SVPWMで出力
void setPhaseVoltage(volatile FOCState_s* foc_state, float angle_el, TIM_HandleTypeDef *htim)
{
    float _sa = sinf(angle_el);
    float _ca = cosf(angle_el);

    foc_state->Ualpha =  _ca * foc_state->Ud - _sa * foc_state->Uq;
    foc_state->Ubeta  =  _sa * foc_state->Ud + _ca * foc_state->Uq;

    foc_state->Ua = foc_state->Ualpha;
    foc_state->Ub = -0.5f * foc_state->Ualpha + _SQRT3_2 * foc_state->Ubeta;
    foc_state->Uc = -0.5f * foc_state->Ualpha - _SQRT3_2 * foc_state->Ubeta;

    float center = VOLTAGE_LIMIT / 2.0f;
    float Umin = fminf(foc_state->Ua, fminf(foc_state->Ub, foc_state->Uc));
    float Umax = fmaxf(foc_state->Ua, fmaxf(foc_state->Ub, foc_state->Uc));
    center -= (Umax + Umin) / 2.0f;

    foc_state->Ua += center;
    foc_state->Ub += center;
    foc_state->Uc += center;

    foc_state->Ua = _constrain(foc_state->Ua, 0.0f, VOLTAGE_LIMIT);
    foc_state->Ub = _constrain(foc_state->Ub, 0.0f, VOLTAGE_LIMIT);
    foc_state->Uc = _constrain(foc_state->Uc, 0.0f, VOLTAGE_LIMIT);

    foc_state->dc_a = _constrain(foc_state->Ua / VOLTAGE_POWER_SUPPLY, 0.0f, 1.0f);
    foc_state->dc_b = _constrain(foc_state->Ub / VOLTAGE_POWER_SUPPLY, 0.0f, 1.0f);
    foc_state->dc_c = _constrain(foc_state->Uc / VOLTAGE_POWER_SUPPLY, 0.0f, 1.0f);

    uint32_t period = __HAL_TIM_GET_AUTORELOAD(htim);
    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_1, (uint32_t)(foc_state->dc_a * period));
    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_2, (uint32_t)(foc_state->dc_b * period));
    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_3, (uint32_t)(foc_state->dc_c * period));

}

/* 1 回の割り込みで呼ばれる高速ループ */
void FOC_FastLoop(void)
{
	FOC_StartupStep();
}


/* ------------------------------------------------------------
 * オープンループで一定角速度を印加するだけのテスト関数
 *  – 速度・電圧は #define で簡単に変えられるようにしてある
 * ------------------------------------------------------------*/
#define TEST_W_RAD   5.0f   // 電流検査は5
#define TEST_UQ_V      1.0f   // q 軸電圧 [V]

volatile ControlMode_e g_control_mode = CTRL_CLOSED_FOC;

void FOC_OpenLoopSensorTest(void)
{
	Update_Magnet_Angle(&angle_sensor_state);
	getDQCurrents(&current_sensor_state, angle_sensor_state.angle_el);
	LPF_current_dq(&current_sensor_state, &foc_state);
    /* 静的変数で角度を自前積分 */
    static float theta = 0.0f;

    /* ---- 角度更新 ---- */
    theta += TEST_W_RAD * DT;
    if (theta > _TWO_PI) theta -= _TWO_PI;

    /* ---- Ud=0, Uq=一定 で SVPWM 出力 ---- */
    foc_state.Ud = 0.0f;
    foc_state.Uq = TEST_UQ_V;
    setPhaseVoltage(&foc_state, theta, &htim1);
}







